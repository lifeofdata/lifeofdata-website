<?php
class coming_soonControllerCsp extends controllerCsp {
	
}