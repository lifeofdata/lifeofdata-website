<?php
class coming_soonViewCsp extends viewCsp {
	public function getComingSoonPageHtml() {
		return parent::getContent('comingSoonPageHtml');
	}
}