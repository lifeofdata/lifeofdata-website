<?php
class meta_infoControllerCsp extends controllerCsp {

}