<div class="cspAdminFooterShell">
	<div class="cspAdminFooterCell">
		<?php echo CSP_WP_PLUGIN_NAME?>
		<?php langCsp::_e('Version')?>:
		<a target="_blank" href="http://wordpress.org/plugins/coming-soon-maintenance-mode-ready/changelog/"><?php echo CSP_VERSION?></a>
	</div>
	<div class="cspAdminFooterCell">|</div>
	<div class="cspAdminFooterCell">
		<?php langCsp::_e('Go')?>&nbsp;<a target="_blank" href="<?php echo $this->getModule()->preparePromoLink('http://readyshoppingcart.com/product/coming-soon-plugin-pro-version/');?>"><?php langCsp::_e('PRO')?></a>
	</div>
	<div class="cspAdminFooterCell">|</div>
	<div class="cspAdminFooterCell">
		<a target="_blank" href="http://wordpress.org/support/plugin/coming-soon-maintenance-mode-ready"><?php langCsp::_e('Support')?></a>
	</div>
	<div class="cspAdminFooterCell">|</div>
	<div class="cspAdminFooterCell">
		Add your <a target="_blank" href="http://wordpress.org/support/view/plugin-reviews/coming-soon-maintenance-mode-ready?filter=5#postform">&#9733;&#9733;&#9733;&#9733;&#9733;</a> on wordpress.org.
	</div>
</div>