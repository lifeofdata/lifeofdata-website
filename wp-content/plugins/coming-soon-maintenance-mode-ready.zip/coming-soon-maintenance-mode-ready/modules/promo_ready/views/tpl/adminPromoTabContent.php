<a target="_blank" href="<?php echo $this->getModule()->preparePromoLink('http://readyshoppingcart.com/product/coming-soon-plugin-pro-version/')?>">
	<img src="<?php echo $this->getModule()->getModPath(). 'img/'. $this->tabCode. '.jpg'?>" />
</a>