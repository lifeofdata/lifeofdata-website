<?php
class shortcodesCsp extends moduleCsp {
    protected $_codesPrepared = false;
    protected $_codes = array(
        /*'category' => array(
			'func' => 'categoriesShortcode', 
			'atts' => array(
				'alias' => array('label' => 'Category Alias'), 
				'id' => array('label' => 'or Category ID'), 
				'shownum' => array('label' => 'Number of products to show'),
				'catalog_view' => array('label' => 'Catalog Items view', 'type' => 'selectbox', 'params' => array('optionsCsp' => array('grid' => 'Grid View', 'list' => 'List View'))),
				
				'grid_preview_size' => array('label' => 'Preview size (grid)'),
				'list_preview_size' => array('label' => 'Preview size (list)'),
				
				'grid_vert_distance' => array('label' => 'Vertical distance (grid)'),
				'grid_hor_distance' => array('label' => 'Horizontal distance (grid)'),
				'list_vert_distance' => array('label' => 'Vertical distance (list)'),
				
				'short_descr_size' => array('label' => 'Short description size (in lines)'),
				
				'hover_item_bg' => array('label' => 'Background when Hovering on product item (grid)'),
				'short_descr_color' => array('label' => 'Short Description text color'),
				'price_color' => array('label' => 'Price color'),
				'image_border_color' => array('label' => 'Product image border color'),
				'title_color' => array('label' => 'Product title color'),
				
				'show' => array('label' => 'Show params', 'type' => 'selectlist', 'params' => array('optionsCsp' => array('shadow_border' => 'Shadow border on product item hover', 'short_descr_hide' => 'Short description', 'catalog_image' => 'Product Image', 'title' => 'Product Title', 'price' => 'Price', 'more' => 'Read More', 'add_to_cart' => 'Add to Cart'))), 
				'exclude' => array('label' => 'Exclude params', 'type' => 'selectlist', 'params' => array('optionsCsp' => array('shadow_border' => 'Shadow border on product item hover', 'short_descr_hide' => 'Short description', 'catalog_image' => 'Product Image', 'title' => 'Product Title', 'price' => 'Price', 'more' => 'Read More', 'add_to_cart' => 'Add to Cart'))),
			), 
			'tpl' => '[%code%%atts%]'),*/
    );
}