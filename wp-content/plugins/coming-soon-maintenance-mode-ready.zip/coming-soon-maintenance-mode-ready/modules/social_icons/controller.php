<?php
class social_iconsControllerCsp extends controllerCsp {
	
}