<a href="http://facebook.com/<?php echo $this->optsModel->get('soc_facebook_link_account')?>">
	<img src="<?php echo $this->getSocImgPath('Facebook-link.png')?>" />
</a>
