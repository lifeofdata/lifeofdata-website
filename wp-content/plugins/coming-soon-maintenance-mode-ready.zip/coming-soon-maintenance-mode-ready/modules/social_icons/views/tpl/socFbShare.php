<fb:share-button 
	href="<?php echo $this->currentUrl?>"
	type="<?php echo $this->optsModel->get('soc_facebook_share_layout')?>"></fb:share-button>