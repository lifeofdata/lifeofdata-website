<div class="g-plusone" 
	 data-size="<?php echo $this->optsModel->get('soc_gp_like_size')?>" 
	 data-annotation="<?php echo $this->optsModel->get('soc_gp_like_annotation')?>" 
	 data-width="<?php echo $this->optsModel->get('soc_gp_like_width')?>"></div>
