<a href="https://plus.google.com/u/0/<?php echo $this->optsModel->get('soc_gp_link_account')?>">
	<img src="<?php echo $this->getSocImgPath('Googleplus-link.png')?>" />
</a>