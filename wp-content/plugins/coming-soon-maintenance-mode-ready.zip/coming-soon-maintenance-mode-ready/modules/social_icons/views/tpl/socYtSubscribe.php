<div class="g-ytsubscribe" 
	 data-channel="<?php echo $this->optsModel->get('soc_yt_account')?>" 
	 data-layout="<?php echo $this->optsModel->get('soc_yt_sub_layout')?>"
	 data-theme="<?php echo $this->optsModel->get('soc_yt_sub_theme')?>"></div>
