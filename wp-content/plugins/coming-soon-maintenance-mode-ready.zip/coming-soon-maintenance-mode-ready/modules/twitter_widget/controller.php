<?php
class twitter_widgetControllerCsp extends controllerCsp {
    
}

