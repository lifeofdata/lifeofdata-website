<?php

class Partials
{
    public $page = array(
        'title'    => 'Page Title',
        'subtitle' => 'Page Subtitle',
        'content'  => 'Lorem ipsum dolor sit amet.',
    );
}
